import tseslint from 'typescript-eslint';
import lwcConfig from '@salesforce/eslint-config-lwc';

export default tseslint.config(
  tseslint.configs.recommended,
  // lwcConfig.configs.base
);