import tseslint from 'typescript-eslint';
import lwcConfig from '@salesforce/eslint-config-lwc';

export default [
  ... tseslint.config(
    tseslint.configs.recommended,
    {
      files: ["**/*.ts"],
      languageOptions: {
        parserOptions: {
          projectService: true
        },
      },
    },
  ),
  ... lwcConfig.configs.base.map(c => {
    return {
      ...c,
      files: ["**/*.js", "**/*.mjs"]
    };
  })
];